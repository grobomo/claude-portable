# SSH Command Quoting — Use Base64

- Complex bash commands through SSH -> docker exec -> bash -c get quoting corrupted
- `$()` command substitution, single quotes, and special chars get evaluated at wrong shell layer
- Fix: base64-encode the script, write to file on target, execute separately
- Pattern: `echo <base64> | base64 -d > /tmp/script.sh && docker cp ... && docker exec bash /tmp/script.sh`
- This is now used in git-dispatch.py for both continuous-claude and simple claude -p dispatch
