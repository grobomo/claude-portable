# Implementation Plan: Seed Worker Bundle

**Branch**: `003-seed-worker-bundle` | **Date**: 2026-03-29 | **Spec**: [spec.md](spec.md)
**Input**: Feature specification from `.specs/seed-worker-bundle/spec.md`

## Summary

Deploy a self-sufficient CCC worker via CloudFormation that builds from an S3-hosted source zip (no GitHub dependency at boot), receives a golden image config-bundle via SCP, and self-validates by completing 3 bridge tasks autonomously. All operations are reusable scripts — zero ad-hoc commands.

## Technical Context

**Language/Version**: Bash scripts (POSIX-compatible), Python 3.x for bridge client
**Primary Dependencies**: AWS CLI (CloudFormation, S3, EC2), SSH/SCP, Docker, config-bundle skill (Node.js)
**Storage**: S3 state bucket (`hackathon26-state-752266476357`) for source zip + heartbeat
**Testing**: Bash validation scripts — submit tasks via bridge.py, poll for completion
**Target Platform**: Ubuntu 22.04 EC2 spot instances (us-east-2)
**Project Type**: Infrastructure scripts + CloudFormation templates
**Performance Goals**: Deploy-to-idle in <15 min, bundle install in <3 min, 3 tasks in <30 min total
**Constraints**: No GitHub clone at boot (air-gap ready), no ad-hoc commands, no SSH intervention during validation
**Scale/Scope**: 1 worker (dev), expandable to N workers with same scripts

## Constitution Check

*No custom constitution defined. Using project rules as gates:*

| Gate | Status | Notes |
|------|--------|-------|
| All AWS resources tagged `Project=hackathon26` | PASS | CF template has tags, deploy-stack.sh adds tags |
| No ad-hoc infra commands | PASS | All ops via scripts/aws/, scripts/fleet/, scripts/test/ |
| Spec exists before code | PASS | This spec |
| Clean git tree before edits | WILL ENFORCE | Commit spec artifacts before implementation |
| No feature code in hackathon26 | PASS | Only scripts and CF templates, no app code |

## Project Structure

### Documentation (this feature)

```text
.specs/seed-worker-bundle/
├── spec.md              # Feature specification
├── plan.md              # This file
├── research.md          # Phase 0: technical decisions
├── data-model.md        # Phase 1: entity definitions
├── quickstart.md        # Phase 1: operator guide
├── checklists/
│   └── requirements.md  # Spec quality checklist
└── tasks.md             # Phase 2: ordered task list
```

### Source Code (repository root)

```text
cloudformation/
├── hackathon26-network.yaml    # existing — SGs
├── hackathon26-storage.yaml    # existing — S3 + IAM
└── hackathon26-worker.yaml     # UPDATE — S3 source zip instead of git clone

scripts/
├── aws/
│   ├── common.sh               # existing — shared constants
│   ├── deploy-stack.sh          # existing — CF create/update
│   ├── delete-stack.sh          # existing — CF teardown
│   ├── get-stack-output.sh      # existing — read outputs
│   ├── list-fleet.sh            # existing — list instances
│   ├── ssh-worker.sh            # existing — SSH by stack name
│   ├── scp-worker.sh            # existing — SCP by stack name
│   ├── docker-exec.sh           # existing — exec in container
│   └── upload-source.sh         # NEW — package + upload claude-portable zip to S3
├── fleet/
│   ├── deploy-bundle.sh         # NEW — build config-bundle, SCP, install
│   └── check-heartbeat.sh       # NEW — read heartbeat from worker
└── test/
    └── validate-worker.sh       # NEW — submit 3 tasks, verify completion
```

**Structure Decision**: Infrastructure scripts organized by concern (aws/fleet/test). No src/ needed — this is an ops project, not an app.

## Complexity Tracking

No violations to justify. Structure is flat and minimal.
