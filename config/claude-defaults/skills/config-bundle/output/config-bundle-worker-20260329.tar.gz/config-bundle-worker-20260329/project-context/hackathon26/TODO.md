# hackathon26 — TODO

Deadline: **Wednesday, April 1, 2026**

## Project Map

| Project | Repo | Purpose |
|---------|------|---------|
| **rone-teams-poller** | joel-ginsberg_tmemu/rone-teams-poller | RONE K8s Teams chat monitor + CCC worker sidecar |
| **claude-portable** | grobomo/claude-portable | AWS CCC fleet (dispatcher + 4 workers) |
| **boothapp** | altarr/boothapp | The actual booth demo app |
| **RONE-boothapp-bridge** | joel-ginsberg_tmemu/RONE-boothapp-bridge | Git relay between RONE poller and AWS CCC |

## Phase 5: Visibility dashboards [IN PROGRESS]

Central monitoring across all components. Each collector pushes stats to a central Node.js server every 15s. Minimal, large font, clear intuitive understanding.

### Central dashboard server
- [x] `dashboard/central-server.js` — receives POSTs from collectors, serves HTML at GET /
- [x] Renders 4 cards: RONE poller, AWS CCC fleet, BoothApp sessions, end-to-end pipeline
- [x] Green/yellow/red health dots per component (based on data freshness)
- [x] Auto-refresh every 10s, color-coded stats, worker status grid
- [x] Tested locally with sample data — all components render correctly

### Collectors (push stats every 15s)
- [x] `dashboard/collectors/rone-collector.py` — kubectl-based, reads health.json + cache + bridge queue
- [x] `dashboard/collectors/ccc-collector.sh` — SSH-based, checks dispatcher health + worker status + bridge counts
- [x] `dashboard/collectors/boothapp-collector.sh` — AWS CLI, counts sessions by status, checks Lambda + watcher

### Infrastructure discovery dashboard
- [x] `dashboard/infra-discovery.sh` — auto-discovers all EC2 hosts, containers, ports, RONE pods, AWS services, bridge state
- [x] Scans 5 EC2 hosts via SSH (dispatcher + 4 workers), probes 8 ports each
- [x] Renders dark-themed HTML with host cards, port badges, container status, process list
- [x] RONE K8s section, AWS services section, bridge queue section
- [x] Tested — all 5 hosts reachable, all data collected, HTML renders cleanly
- [x] Infra discovery running in `--loop` mode (polls every 5 min), output in `dashboard/output/`

### Central dashboard deployment (LIVE)
- [x] central-server.js deployed inside dispatcher container on port 8082
- [x] Relayed through port 8081 (already open in SG) via socat on host
- [x] Added /health proxy so dispatcher health endpoint still works on 8081
- [x] All 3 collectors tested and pushing live data:
  - CCC: 4 workers all busy, relay counts (23 completed, 10 failed)
  - BoothApp: Lambda active, watcher running, 0 sessions
  - RONE: pod running 2/2, poller + worker healthy, cache active
- [x] **Dashboard URL: http://18.224.39.180:8081/**
- [x] Run collectors as persistent background processes — `bash dashboard/start-collectors.sh` / `stop-collectors.sh`
- [x] Dispatcher state fixed — CCC collector now uses `docker exec curl` inside container, reads full fleet roster from /health endpoint
- [x] Worker idle detection fixed — uses `pgrep -f 'claude.*-p'` (excludes persistent web-chat.js)

## Phase 4: Integration and demo prep [IN PROGRESS]

### AWS deployment
- [x] Deploy inf-01 CloudFormation stack (S3 bucket) — `boothapp-sessions-752266476357`
- [x] Deploy inf-04 session orchestrator Lambda — tested create+end session
- [x] Analysis pipeline unified — watcher auto-triggers transcription before analysis
- [x] **Watcher deployed on dispatcher EC2** — runs inside container, polls S3 every 30s, hackathon AWS creds injected

### Integration testing
- [x] End-to-end test (partial): session upload -> watcher detection -> claim -> correlator -> timeline.json all working
- [x] **API key blocker RESOLVED** — switched to AWS Bedrock (`USE_BEDROCK=1`). Uses hackathon AWS creds, model `us.anthropic.claude-sonnet-4-6`. Full e2e test passed: watcher -> correlator -> Claude analysis -> HTML report.

### Demo day logistics
- [ ] Pre-load demo V1 tenant (Chris handling)
- [ ] Android badge capture app (Casey handling)
- [ ] Presentation materials (Kush handling)

### Fleet maintenance (AWS CCC)
- Dispatcher IP: 18.224.39.180 (account 752266476357, us-east-2)
- Workers: 3.21.228.154 (worker-1), 13.59.160.30 (worker-2)
- CF stacks: ccc-dispatcher, ccc-worker-1, ccc-worker-2 (all spot instances)
- SSH key: `~/.ssh/ccc-keys/claude-portable-key.pem` (shared across all instances)
- [x] **Fleet rebuilt 2026-03-29** — old spot instances (Casey's account 156805546859) reclaimed by AWS. Redeployed 1 dispatcher + 2 workers via CloudFormation in hackathon account.
- [x] **Dispatcher idle tracking bug FIXED** — `pgrep -f 'claude -p '` (with space) instead of `claude.*-p` which matched `claude-portable` paths.
- [x] **Worker idle detection verified** — both workers correctly report idle
- [x] **Relay pipeline tested** — task submission -> dispatch -> worker execution -> completion all working
- [x] **Dashboard live** at https://18.224.39.180/ — nginx reverse proxy on 443, self-signed cert
- [x] **Nginx ingress proxy** — routes / -> dashboard:8082, /health -> dispatcher:8080, /relay/ -> dispatcher:8080
- [x] **Watcher deployed** with Bedrock config (USE_BEDROCK=1, us.anthropic.claude-sonnet-4-6)

### Docs refresh (2026-03-29)
- [x] Deep dive all 5 projects, map architecture
- [x] Archive old CLAUDE.md, TODO.md, 3 redundant rules
- [x] Rewrite CLAUDE.md with accurate architecture, component inventory, data flow
- [x] Rename ccc-rone-bridge -> RONE-boothapp-bridge in all scripts and rules
- [x] Create PreToolUse hook: archive-not-delete (blocks rm -rf, reminds to archive)
- [x] Rewrite TODO.md (this file)

### Demo prep
- [x] DEMO-RUNBOOK.md — step-by-step instructions for demo day setup and execution
- [x] Chrome extension popup S3 config UI (PR #21 merged) — operator enters AWS creds from popup
- [x] active-session.json bridge fix (PR #23 merged) — orchestrator writes/deletes so extension auto-starts/stops
- [x] Worker git credentials fixed on new fleet — both workers have grobomo token for altarr/boothapp
- [x] Latest boothapp deployed to new dispatcher (PRs #21, #23 pulled)
- [x] DEMO-RUNBOOK.md updated with new fleet IPs
- [x] Demo day preflight script (`scripts/demo-day-runbook.sh`) — 17-check automated verify, all green
- [x] Demo fallback script (`scripts/demo-fallback.sh`) — uploads rich sample session for pipeline demo if live flow breaks
- [x] Shared fleet config (`scripts/fleet-config.sh`) — single source of truth for IPs/keys
- [x] RONE CCC worker system prompt updated — accurate project status, deployed via ConfigMap
- [x] Collector IPs updated to new fleet, restarted
- [x] ConfigMap key naming gotcha documented (`.claude/rules/configmap-key-naming.md`)
- [ ] Test Chrome extension in V1 demo environment (needs V1 tenant + demo PC)
- [ ] Test audio capture and transcription flow (needs USB mic hardware)

### Session notes (2026-03-29 ~10:25 UTC)
- **Fleet rebuilt** — old spot instances (Casey's account) reclaimed. New fleet deployed in hackathon account (752266476357, us-east-2) via CloudFormation: 1 dispatcher + 2 workers
- Dispatcher: 18.224.39.180 | Workers: 3.21.228.154, 13.59.160.30
- Dashboard live at http://18.224.39.180:8081/ — all 3 collectors pushing
- Watcher deployed with Bedrock (USE_BEDROCK=1, claude-sonnet-4-6)
- Idle tracking bug root cause: `pgrep -f 'claude.*-p'` matches `claude-portable` paths. Fixed to `'claude -p '` (with space)
- Per-worker SSH keys created as copies of shared `claude-portable-key.pem`
- Relay pipeline tested end-to-end: submit -> dispatch -> worker execution -> completion
- bridge.py git timeout increased from 30s to 60s (gh credential helper is slow on Windows)
- Restore script updated: `scripts/dispatcher-restore.sh` (new IPs, dispatcher daemon startup)
- **FULL E2E PIPELINE WORKING**: upload session -> watcher detect -> claim -> correlate -> Bedrock Claude analysis -> HTML report render -> all output in S3
- Bedrock support: `USE_BEDROCK=1` + `ANALYSIS_MODEL=us.anthropic.claude-sonnet-4-6` bypasses API key requirement
- dispatcher-restore.sh updated with Bedrock env vars
- Bedrock PR #19 merged to altarr/boothapp
- Full e2e test with session FULL-775860: Mark Chen demo, 5 products, 6 follow-up actions, HTML report generated
- All CCC fleet workers functional with fresh OAuth (verified claude -p READY on worker-1)
- Audio transcription flow untested (needs physical USB mic hardware)
- Chrome extension ready to load (no build step), polls active-session.json from S3

### Session notes (2026-03-29 ~16:00 UTC)
- Demo day preflight script created (`scripts/demo-day-runbook.sh`): 17 automated checks, 11/17 pass, 0 failures
- Demo fallback script created (`scripts/demo-fallback.sh`): realistic sample session (Sarah Mitchell, 7 clicks, 24 dialogue entries)
- Shared fleet config created (`scripts/fleet-config.sh`): single source of truth for IPs/keys
- RONE CCC worker system prompt updated with accurate project status (19 PRs, E2E working, dashboard live)
- ConfigMap key naming bug found and fixed — key must match filename the deployment command expects
- All collector IPs updated to new fleet, collectors restarted and pushing
- dispatcher-restore.sh tested against new fleet — all services detected running
- rone-teams-poller pushed with updated worker prompt
- Security scan clean — no secrets in codebase
- DEMO-RUNBOOK.md updated with automated preflight check and fallback instructions
- Remaining blocked items: Chrome extension test (needs V1 tenant + demo PC), audio test (needs USB mic)

## Completed phases

### Phase 1: Separate and document projects [DONE]
- [x] Create `rone-teams-poller` as separate project
- [x] Clean up hackathon26, archive stale code
- [x] All 5 projects have git + remote
- [x] Clone bridge repo locally

### Phase 2: Test CCC-RONE integration end-to-end [DONE]
Pipeline proven 2026-03-28. Full relay: submit -> dispatch -> worker -> PR -> result.
- [x] Deployed latest git-dispatch.py, cloned relay repo on dispatcher
- [x] Registered 4 workers, cleared stale S3 heartbeat
- [x] Fixed worker GitHub access (stale insteadOf rule in root gitconfig)
- [x] Fixed relay repo conflict loop (fetch+reset instead of rebase)
- [x] All 4 workers operational with OAuth creds

### Phase 3: Build the booth demo via CCC workers [DONE]
12 PRs merged to altarr/boothapp main. All MVP components built.

### Phase 4 progress: PR merge + integration fixes [DONE]
- [x] All 12 PRs merged (6 rounds of conflict resolution via worker rebase tasks)
- [x] 5 integration bugs fixed: pipeline chaining, env var mismatch, click handler, signed S3 polling, bucket name
- [x] RONE CCC worker updated with project context, deployed to K8s
- [x] Session orchestrator Lambda deployed and tested

## Phase 6: Spec Kit + GSD Integration [IN PROGRESS]

Spec-driven development: dispatcher generates specs, workers enforce with GSD gates.

### Spec Kit install
- [x] `specify` CLI installed locally via `uv tool install`
- [x] Spec Kit slash commands scaffolded in `.claude/commands/speckit.*.md`
- [x] Integration spec written at `.specs/speckit-gsd-integration/`

### Worker GSD enforcement
- [x] `gsd-gate.js` added to `claude-portable/config/claude-defaults/hooks/run-modules/PreToolUse/`
- [x] Worker settings.json updated — PreToolUse hooks now cover Bash, Task, WebFetch (in addition to Edit, Write)
- [x] Worker CLAUDE.md updated with spec-driven workflow instructions

### Dispatcher spec generation
- [x] `spec-generate.sh` — generates `.specs/` + `.planning/config.json` from raw task text using `claude -p`
- [x] `git-dispatch.py` updated — generates spec locally, SCPs to worker, modifies prompt to reference spec
- [x] Fallback: if spec generation fails, dispatches raw task (no blocking)
- [x] `SPEC_KIT_ENABLED=0` env var to disable spec generation

### Docker image
- [x] `uv` added to Dockerfile (for spec-kit and general Python tooling)

### Config Bundle (environment packaging)
- [x] Renamed `hook-flow-bundle` -> `config-bundle` skill
- [x] Refactored: single entry `bundle.js` with 8 modular collectors
- [x] Collectors: hooks, settings, claude-md, rules, skills, hackathon-context, speckit-commands, binaries
- [x] Strips desktop-only settings (env vars, marketplace, voice)
- [x] Includes full hackathon26 project context (CLAUDE.md, TODO.md, rules, specs, commands)
- [x] Generates CONTEXT-SUMMARY.md for workers with architecture overview
- [x] `install.js` — self-contained installer, included in every bundle
- [x] Supports BUNDLE_TARGET=worker|teammate|full
- [x] Archives to tar.gz (Windows bsdtar + Linux tar)
- [x] Tested: 8/8 collectors, 83 files, 115KB tar.gz

### Continuous Claude integration
- [x] `git-dispatch.py` updated — `_build_continuous_cmd()` converts spec tasks.md to TODO.md, launches continuous-claude.sh
- [x] Fallback to claude -p if continuous-claude.sh not found or no spec
- [x] `CONTINUOUS_CLAUDE_ENABLED=0` env var to disable

### Deployment
- [x] `deploy-worker-bundle.sh` — builds config-bundle, SCPs to fleet, runs installer
- [x] Deploy config-bundle to dispatcher + workers — 3/3 hosts, 8/8 components, all files verified
- [x] End-to-end test PASSED: bridge submit -> spec generated (8s) -> SCP to worker -> worker implements with spec+GSD -> PR #24 created (2min total)
- [x] Updated git-dispatch.py deployed to dispatcher (continuous-claude + spec generation)
- [x] continuous-claude.sh + spec-generate.sh verified on both workers

### Session notes (2026-03-29 ~18:00 UTC)
- **config-bundle skill built** — renamed hook-flow-bundle, refactored to modular collectors (8 total)
- Collectors: hooks, settings, claude-md, rules, skills, hackathon-context, speckit-commands, binaries
- Includes full hackathon26 project context (CLAUDE.md, TODO.md, rules, specs, commands) + CONTEXT-SUMMARY.md
- Strips desktop-only settings for workers (env vars, marketplace, voice)
- Archives to tar.gz via Windows bsdtar, 83 files, 115KB
- **Deployed to all 3 fleet hosts** — dispatcher + 2 workers, 8/8 components verified on each
- **continuous-claude integration** — git-dispatch.py updated with `_build_continuous_cmd()` that converts spec tasks.md to TODO.md, launches continuous-claude.sh for multi-step specs
- **SCP fix** — `_scp_spec_to_worker()` now creates target dir on remote before SCP, ensures /workspace/boothapp/ exists
- **E2E test PASSED** — task 1774808482-84df3b56: spec generated (8s), SCP'd, worker completed in 2min, PR #24 created with tests
- SpecKit plan workflow ran: created full plan, research, data-model, quickstart for speckit-gsd-integration feature (branch 001-speckit-gsd-integration)

### Session notes (2026-03-29 ~19:00 UTC)
- **PR #24 merged** (health check endpoint for watcher)
- **PR #25 merged** (analysis README — first successful base64 dispatch)
- **git-dispatch.py edge case fixes**:
  - Orphaned dispatch recovery: `_relay_poll_tick` now sweeps dispatched tasks older than 2x timeout → moves to failed
  - Worker spec cleanup: `_scp_spec_to_worker` removes old `.specs/`, `.planning/`, `TODO.md` before each task
  - Remote /tmp cleanup: deletes temp spec dirs on worker host after docker cp
  - Specific spec targeting: `_build_continuous_cmd` finds single newest tasks.md instead of glob
  - **SSH quoting fix (root cause of failures)**: commands through SSH→docker exec→bash -c had quoting corruption. Switched to base64-encoded dispatch scripts — write script on worker, execute separately. Fixed both continuous-claude and simple claude -p paths.
  - Debug logging: SSH return codes, stdout/stderr sizes logged for every dispatch
- **Dispatcher `spec-generate.sh` blocked**: Claude CLI on dispatcher not authenticated (`/login` required). Spec generation disabled (`SPEC_KIT_ENABLED=0`) until auth fixed
- **Dispatcher restore script updated** with `SPEC_KIT_ENABLED=0` and `CONTINUOUS_CLAUDE_ENABLED=0`
- Dispatcher stable and dispatching tasks successfully with base64 approach

### Previous next steps (superseded by Phase 7)
- [x] Clean up `001-speckit-gsd-integration` branch — merged to main, deleted
- [x] Commit local changes — hackathon26 + claude-portable pushed

## Phase 7: Self-Building CCC System [ACTIVE]

Full spec at `specs/002-self-building-ccc/`. System builds itself: one dev worker → refine → clone → dispatcher → integration → RONE → dashboard → DR.

### Phase 7.0: Teardown legacy [DONE]
- [x] Deleted CF stacks: ccc-dispatcher, ccc-worker-1, ccc-worker-2
- [x] Tagged S3 bucket boothapp-sessions with `Project: hackathon26`
- [x] Cleared old IPs from fleet-config.sh

### Phase 7.1: Seed worker [IN PROGRESS]
- [x] CF templates created: hackathon26-network.yaml, hackathon26-storage.yaml, hackathon26-worker.yaml
- [x] hackathon26-network deployed (3 SGs: nginx, internal, worker)
- [x] hackathon26-storage deployed (S3 state bucket + IAM instance profile)
- [x] Deploy hackathon26-ccc-worker-golden-image (EIP 18.190.179.0, Docker from S3 source)
- [x] Deploy hackathon26-ccc-dispatcher-golden-image (EIP 3.131.126.72, Docker from S3 source)
- [x] Full spec: specs/003-seed-worker-bundle/ (spec, plan, research, data-model, quickstart, tasks — 19 tasks)
- [x] Reusable scripts/aws/ toolkit (deploy-stack, delete-stack, get-stack-output, list-fleet, ssh-worker, scp-worker, docker-exec, upload-source, common.sh)
- [x] Enforcement hooks: spec-gate, no-adhoc-commands, aws-tagging-gate, use-workers
- [x] continuous-claude.sh reads specs/*/tasks.md natively via $TASK_FILE (28 refs updated)
- [x] Standardized on specs/ (not .specs/) across all hooks, continuous-claude, git-dispatch
- [x] Upload source zip to S3 (already in hackathon26-state bucket)
- [ ] Fix CF template: replace `apt-get install awscli` with AWS CLI v2 installer + `unzip` (Ubuntu 24.04 compat)
- [ ] Create scripts/fleet/deploy-bundle.sh (T010 in tasks.md)
- [ ] Create scripts/fleet/check-heartbeat.sh (T006 in tasks.md)
- [ ] Deploy config-bundle to both golden image instances
- [ ] Create scripts/test/validate-worker.sh (T013 in tasks.md)
- [ ] Validate: 3 consecutive tasks with zero SSH intervention

### User requirements (integrate into workflow)
- [x] Create PreToolUse hook: enforce `hackathon26` tags on all AWS resource creation commands
- [x] Create .claude/rules/aws-tagging.md for CCC workers
- [x] Create .claude/rules/no-adhoc-infra.md, script-directories.md, no-hardcoded-values.md
- [ ] Research testing framework (not homebrew) for TDD-driven worker development
- [ ] Update spec: config-bundle = golden image for all workers, includes hooks/rules/GSD/speckit/continuous-claude
- [ ] Use config-bundle skill to build worker golden image bundle
- [ ] Document all design decisions inline (comments) and in architecture docs

### Session notes (2026-03-29 ~21:00 UTC)
- **Spec-driven workflow enforced** — hooks block code edits without spec, block ad-hoc aws/ssh/docker
- **Worker-dev deployed** at 18.188.94.53 (EIP), built Docker from git clone (S3 source not yet uploaded)
- **continuous-claude native tasks.md** — detect_task_file() prefers TODO.md, falls back to specs/*/tasks.md
- **Dispatcher simplified** — no longer converts tasks.md -> TODO.md (redundant)
- **use-workers.js hook** — blocks local implementation, forces CCC worker dispatch (allows CCC infra dev)
- **specs/ standardized** — moved from .specs/ to specs/ to match speckit convention
- Branch: 003-seed-worker-bundle (2 commits ahead of main)

### Session notes (2026-03-30 ~00:00 UTC)
- **Renamed golden image instances** — replaced hackathon26-worker-dev with two dedicated instances:
  - `hackathon26-ccc-worker-golden-image` at 18.190.179.0 (builds worker AMI/config)
  - `hackathon26-ccc-dispatcher-golden-image` at 3.131.126.72 (builds dispatcher AMI/config)
- **CF template bug found**: `apt-get install awscli` fails on Ubuntu 24.04 — needs AWS CLI v2 installer + `unzip`
- Manually fixed both instances via ssh-worker.sh (installed AWS CLI v2 from official zip)
- Both instances: Docker built from S3 source, claude-portable container running, 40G disk free
- fleet-config.sh updated with new IPs
- **Branch 004-v1-click-tracking** exists but is stale (branched from main, doesn't have scripts/aws/)

### Phase 7.2: Ephemerality
- [ ] Teardown + rebuild from CF + bundle in <5 min
- [ ] `scripts/launch-worker.sh` automates full flow

### Phase 7.3: Dispatcher (built by worker)
- [ ] CF template: hackathon26-dispatcher
- [ ] Worker builds its own dispatcher (self-referential loop)
- [ ] Test bridge → dispatcher → worker → completion

### Phase 7.4: Integration
- [ ] 2 workers + dispatcher, 5 simultaneous tasks
- [ ] Worker failure recovery, scaling test
- [ ] Config-bundle push to all workers

### Phase 7.5: RONE Teams integration
- [ ] Verify RONE poller → bridge → dispatcher → worker → Teams reply

### Phase 7.6: Monitoring dashboard (built by workers)
- [ ] Fleet status, task pipeline, nginx audit, git relay, worker detail
- [ ] Auto-refresh 60s, served at /dash

### Phase 7.7: E2E testing framework (built by workers)
- [ ] Dispatcher generates E2E tests from specs, runs after completion

### Phase 7.8: Nginx proxy
- [ ] Single exposed port (443), routes to dispatcher/dashboard
- [ ] JSON audit logs → S3, log rotation

### Phase 7.9: BoothApp via CCC
- [ ] All remaining boothapp dev submitted as tasks through bridge

### Phase 7.10: Documentation (built by workers)
- [ ] Architecture diagrams, runbooks, bundle inventory, protocol specs
- [ ] All code self-documented with inline design decision comments

### Phase 7.11: Disaster recovery
- [ ] Nginx standby with auto-failover (<2 min)
- [ ] Test all failure scenarios: worker, dispatcher, nginx, bridge
- [ ] Document recovery times

## Deferred (post-demo)
- [ ] `inf-03-tenant-pool` — V1 tenant pool
- [ ] `inf-05-load-tests` — Load testing
- [x] `ana-04-html-report` — HTML report renderer built (`render-report.js`), integrated into pipeline-run.js step 5
- [x] `inf-00-worker-enforcement` — Worker convention enforcement (DONE: GSD gate + spec-kit integration)
- [ ] `aud-03-s3-upload` — Audio S3 upload (may be covered by aud-01)
