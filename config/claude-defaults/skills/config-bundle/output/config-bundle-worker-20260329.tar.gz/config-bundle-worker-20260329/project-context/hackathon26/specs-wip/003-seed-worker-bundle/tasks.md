# Tasks: Seed Worker Bundle

**Input**: Design documents from `.specs/seed-worker-bundle/`
**Prerequisites**: plan.md, spec.md, research.md, data-model.md, quickstart.md

## Format: `[ID] [P?] [Story] Description`

- **[P]**: Can run in parallel (different files, no dependencies)
- **[Story]**: Which user story (US1, US2, US3)
- Exact file paths in every description

---

## Phase 1: Setup

**Purpose**: Commit spec artifacts, ensure clean tree for implementation

- [ ] T001 Commit all spec artifacts (.specs/seed-worker-bundle/) and new hooks to git on branch 003-seed-worker-bundle
- [ ] T002 Verify scripts/aws/common.sh has correct S3 state bucket name and all shared constants

**Checkpoint**: Clean git tree, spec committed, ready for implementation.

---

## Phase 2: Foundational (S3 Source Zip Pipeline)

**Purpose**: Get claude-portable source into S3 so the CF template can reference it. BLOCKS US1.

- [ ] T003 Create scripts/aws/upload-source.sh — packages claude-portable repo as tar.gz, uploads to s3://hackathon26-state-752266476357/source/claude-portable.tar.gz, records git hash
- [ ] T004 Update cloudformation/hackathon26-worker.yaml — replace git clone with S3 download of source tar.gz, extract, docker build from local dir
- [ ] T005 Run scripts/aws/upload-source.sh and verify the tar.gz exists in S3 with correct size

**Checkpoint**: Source zip in S3, CF template references it. Worker deploy can proceed.

---

## Phase 3: User Story 1 - Deploy Worker From Scratch (Priority: P1)

**Goal**: Single script deploys a worker from zero to idle heartbeat in <15 min, using S3 source zip.

**Independent Test**: `bash scripts/aws/deploy-stack.sh hackathon26-worker-dev cloudformation/hackathon26-worker.yaml WorkerName=hackathon26-worker-dev InstanceType=t3.large` then `bash scripts/fleet/check-heartbeat.sh hackathon26-worker-dev` returns idle.

### Implementation for User Story 1

- [ ] T006 [US1] Create scripts/fleet/check-heartbeat.sh — SSH to worker, read /workspace/.heartbeat.json, print status, exit 0 if idle/running, exit 1 if error/missing. Retry with backoff for boot period.
- [ ] T007 [US1] Deploy hackathon26-worker-dev stack via scripts/aws/deploy-stack.sh with updated CF template
- [ ] T008 [US1] Wait for boot completion using scripts/fleet/check-heartbeat.sh (poll until idle, timeout 15 min)
- [ ] T009 [US1] Verify: heartbeat reports status=idle, container=running, disk_free reasonable. No GitHub clone in /var/log/hackathon26-init.log.

**Checkpoint**: Worker deployed from S3 source, heartbeat reporting idle. No GitHub dependency at boot.

---

## Phase 4: User Story 2 - Golden Image Bundle Install (Priority: P1)

**Goal**: Single script builds config-bundle locally, SCPs to worker, installs all hooks/rules/skills/binaries + Claude auth.

**Independent Test**: `bash scripts/fleet/deploy-bundle.sh hackathon26-worker-dev` then verify 8 components installed via docker exec.

### Implementation for User Story 2

- [ ] T010 [US2] Create scripts/fleet/deploy-bundle.sh — builds config-bundle (node ~/.claude/skills/config-bundle/bundle.js), SCPs tar.gz to worker, docker cp into container, runs install.js, injects ANTHROPIC_API_KEY from OS credential store
- [ ] T011 [US2] Run scripts/fleet/deploy-bundle.sh against hackathon26-worker-dev
- [ ] T012 [US2] Verify: all hooks exist in container (spec-gate, gsd-gate, enforcement-gate, no-adhoc-commands, archive-not-delete, aws-tagging-gate), claude --version works, API key set

**Checkpoint**: Worker has full golden image config. Ready to accept tasks autonomously.

---

## Phase 5: User Story 3 - Self-Validation (Priority: P2)

**Goal**: Single script submits 3 test tasks through bridge, verifies all complete with zero SSH intervention.

**Independent Test**: `bash scripts/test/validate-worker.sh hackathon26-worker-dev` exits 0 with "VALIDATED: 3/3 tasks passed".

### Implementation for User Story 3

- [ ] T013 [US3] Create scripts/test/validate-worker.sh — submits 3 small tasks via bridge.py (e.g. "create a file /workspace/test-1.txt with contents 'hello'"), polls bridge for completion, checks results, prints pass/fail per task, exits 0 if 3/3 pass
- [ ] T014 [US3] Run scripts/test/validate-worker.sh against hackathon26-worker-dev
- [ ] T015 [US3] Verify: 3/3 tasks complete, script prints "VALIDATED: 3/3 tasks passed", exit code 0

**Checkpoint**: Worker proven production-ready via automated validation.

---

## Phase 6: Polish & Cross-Cutting

**Purpose**: Update docs, clean up, ensure repeatability

- [ ] T016 [P] Update TODO.md — mark Phase 7.1 tasks complete, add session notes
- [ ] T017 [P] Update scripts/fleet-config.sh with worker-dev IP from CF output
- [ ] T018 Run full teardown + rebuild cycle: delete-stack, deploy-stack, deploy-bundle, validate — confirm SC-005 (reproducible)
- [ ] T019 Commit all implementation to branch 003-seed-worker-bundle, merge to main

---

## Dependencies & Execution Order

### Phase Dependencies

- **Setup (Phase 1)**: No dependencies — start immediately
- **Foundational (Phase 2)**: Depends on Phase 1 (clean tree)
- **US1 (Phase 3)**: Depends on Phase 2 (S3 source zip)
- **US2 (Phase 4)**: Depends on Phase 3 (running worker)
- **US3 (Phase 5)**: Depends on Phase 4 (bundled worker)
- **Polish (Phase 6)**: Depends on Phase 5

### Within Each Phase

- Tasks within a phase are sequential unless marked [P]
- Commit after each phase checkpoint

### Parallel Opportunities

- T016 and T017 can run in parallel (different files)
- In a multi-worker scenario, US1 could be parallelized across workers

---

## Implementation Strategy

### MVP First (US1 Only)

1. Phase 1 + 2: Setup + source zip
2. Phase 3: Deploy worker, verify heartbeat
3. **STOP and VALIDATE**: Worker boots from S3, no GitHub

### Full Delivery

1. Phases 1-3: MVP worker deployed
2. Phase 4: Bundle installed, worker autonomous
3. Phase 5: Self-validated, production-ready
4. Phase 6: Documented, reproducible, merged

---

## Notes

- All scripts must source scripts/aws/common.sh
- No ad-hoc aws/ssh/docker commands — hooks enforce this
- Each phase checkpoint = git commit
- Spec gate blocks code edits until this spec exists (it does)
