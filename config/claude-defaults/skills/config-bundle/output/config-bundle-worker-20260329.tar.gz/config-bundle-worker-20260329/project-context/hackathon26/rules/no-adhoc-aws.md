# No Ad-Hoc AWS Commands

NEVER run raw `aws` CLI commands directly. Use reusable scripts in `scripts/aws/`.

- `scripts/aws/deploy-stack.sh <stack-name> <template> [params...]` — deploy/update CF stack
- `scripts/aws/delete-stack.sh <stack-name>` — tear down CF stack
- `scripts/aws/get-stack-output.sh <stack-name> <output-key>` — read stack outputs
- `scripts/aws/list-fleet.sh` — list all hackathon26 instances with IPs and status
- `scripts/aws/ssh-worker.sh <worker-name> [command]` — SSH to a worker by name (resolves IP from CF)

All scripts enforce `--profile hackathon`, `--region us-east-2`, and `Project=hackathon26` tags.
CCC workers use these scripts too — no human in the loop.
If a script doesn't exist for what you need, CREATE IT in `scripts/aws/` first, then use it.
