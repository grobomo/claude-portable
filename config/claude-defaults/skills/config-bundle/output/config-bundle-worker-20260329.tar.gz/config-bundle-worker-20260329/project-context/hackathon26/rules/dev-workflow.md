# Development Workflow

All work follows: SpecKit -> GSD -> Feature Branch -> Continuous Claude -> PRs.

1. `/speckit.specify` + `/speckit.plan` + `/speckit.tasks` — plan everything first
2. Feature branch from main: `git checkout -b <NNN>-<feature-name>`
3. Run continuous-claude with `TASK_FILE=specs/<feature>/tasks.md`
4. Each task = commit + PR. User tracks via branches and PRs.
5. CCC workers also use continuous-claude when implementing in boothapp.

Hooks enforce this. See `~/.claude/rules/workflow-hook-enforcement.md`.
