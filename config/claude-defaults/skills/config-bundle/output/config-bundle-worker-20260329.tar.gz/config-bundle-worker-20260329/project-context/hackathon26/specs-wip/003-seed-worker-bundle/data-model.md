# Data Model: Seed Worker Bundle

## Entities

### Worker Stack
- **stack_name**: string — CF stack identifier (e.g. `hackathon26-worker-dev`)
- **instance_id**: string — EC2 instance ID
- **public_ip**: string — Elastic IP address
- **worker_name**: string — hostname and heartbeat identifier
- **instance_type**: string — EC2 instance size
- **status**: enum — CF stack status (CREATE_COMPLETE, etc.)

### Source Zip
- **s3_bucket**: string — `hackathon26-state-752266476357`
- **s3_key**: string — `source/claude-portable.tar.gz`
- **version**: string — git commit hash at time of packaging
- **size_bytes**: integer — archive size
- **uploaded_at**: ISO 8601 timestamp

### Config Bundle
- **components**: list — hooks, rules, skills, settings, claude-md, hackathon-context, speckit-commands, binaries
- **target**: enum — worker | teammate | full
- **archive_path**: string — local path to tar.gz
- **installed_at**: ISO 8601 timestamp (written to worker after install)

### Heartbeat
- **worker**: string — worker name
- **status**: enum — idle | running | error
- **container**: string — Docker container state (running, stopped, missing)
- **pid**: integer — Claude process PID (0 if idle)
- **timestamp**: ISO 8601
- **disk_free**: string — free disk on workspace volume
- **uptime**: float — system uptime seconds

### Bridge Task (reference — owned by RONE-boothapp-bridge)
- **id**: string — `{timestamp}-{hex}`
- **sender**: string — task submitter
- **text**: string — task description
- **state**: enum — pending | dispatched | completed | failed
