# Spec: Self-Building CCC System

## Problem Statement

The current CCC fleet was hand-assembled across multiple sessions — ad-hoc SSH, manual docker cp, incremental fixes. Configuration drift between workers, stale code on dispatcher, no reproducibility. If a spot instance gets reclaimed, rebuilding takes an entire session of manual work.

The system should build itself. A single dev worker container is refined iteratively until it can reliably execute tasks. That container becomes the template for all workers. The dispatcher, bridge, monitoring — everything — gets built BY the workers, not by Joel on his laptop.

## Resource Labeling

All AWS resources created by this system MUST be tagged:
- `Project: hackathon26`
- `Component: ccc-{worker|dispatcher|nginx|bridge}`
- `ManagedBy: cloudformation`

All CloudFormation stack names prefixed with `hackathon26-`. All S3 buckets, security groups, IAM roles include `hackathon26` in the name. This enables clean teardown: `aws cloudformation delete-stack --stack-name hackathon26-*`.

Existing unlabeled resources (ccc-dispatcher, ccc-worker-1, ccc-worker-2, boothapp-sessions-752266476357) are legacy from the hand-built phase and will be torn down before this spec begins.

## Architecture

```
                    ┌─────────────────────────────────────────────┐
                    │              AWS Account 752266476357        │
                    │              Region: us-east-2               │
                    │                                             │
   Internet ──────▶ │  ┌──────────┐                               │
                    │  │  nginx   │ :443 (only exposed port)      │
                    │  │  proxy   │ audit logs → S3               │
                    │  └────┬─────┘                               │
                    │       │                                     │
                    │  ┌────┴────────────────────────┐            │
                    │  │         routes:              │            │
                    │  │  /health  → dispatcher:8080  │            │
                    │  │  /dash    → dashboard:8082   │            │
                    │  │  /audit   → nginx access log │            │
                    │  └────┬────────────────────────┘            │
                    │       │                                     │
                    │  ┌────▼─────┐    ┌──────────┐              │
                    │  │dispatcher│◄──▶│ git-relay │ (bridge repo)│
                    │  │ :8080    │    │  repo     │              │
                    │  └────┬─────┘    └──────────┘              │
                    │       │                                     │
                    │  ┌────▼─────┐  ┌──────────┐               │
                    │  │ worker-1 │  │ worker-2 │  ... worker-N  │
                    │  │ (claude) │  │ (claude) │               │
                    │  └──────────┘  └──────────┘               │
                    │                                             │
                    │  ┌──────────┐                               │
                    │  │ S3 bucket│ sessions, audit logs, state   │
                    │  └──────────┘                               │
                    └─────────────────────────────────────────────┘

External inputs:
  - RONE Teams Poller (K8s) ──▶ git-relay repo ──▶ dispatcher
  - Joel's laptop ──▶ git-relay repo ──▶ dispatcher
  - Joel's laptop ──▶ nginx :443 ──▶ dashboard/health
```

## Network Security

- **Single entry point**: Only the nginx proxy EC2 instance has a security group allowing inbound 443.
- **All other instances**: Security groups allow inbound ONLY from the nginx proxy's security group + SSH from Joel's IP.
- **Workers**: No inbound ports at all. Workers pull work from dispatcher via SSH (dispatcher initiates). Workers push code to GitHub (outbound HTTPS).
- **Outbound**: All instances allow outbound to internet (GitHub, npm, pip, Anthropic API, AWS APIs).
- **No direct SSH from internet to workers or dispatcher** — SSH through nginx as jump host if needed.

## Nginx Audit Logging

The nginx proxy logs ALL requests to `/var/log/nginx/audit.log` in JSON format:
```json
{"time":"$time_iso8601","remote":"$remote_addr","method":"$request_method","uri":"$uri","status":$status,"bytes":$body_bytes_sent,"upstream":"$upstream_addr","latency":$request_time}
```

Logs rotate daily, ship to S3 bucket (`hackathon26-audit-logs-{account_id}`). The dashboard reads these logs for the health/security panel.

## Environment Bundle

The AWS environment is treated as **airgapped for inbound tooling**. All tools, configs, binaries are pre-bundled into a single archive and delivered to workers locally (SCP from dispatcher or baked into AMI/Docker image).

### Bundle contents
| Category | Contents |
|----------|----------|
| **Claude Code** | `claude` CLI binary (pinned version) |
| **MCP servers** | mcp-manager, blueprint-extra-mcp, v1-api (all as npm packages or binaries) |
| **Hooks** | run-pretooluse.js, run-posttooluse.js, run-stop.js + all modules (GSD gate, enforcement, rule-hygiene, auto-continue) |
| **Settings** | settings.json (stripped of desktop-only config), settings.local.json |
| **Rules** | All .claude/rules/ from hackathon26 + global rules |
| **Skills** | auto-gsd, code-review, config-bundle, rone-chat |
| **SpecKit** | .claude/commands/speckit.*.md, .specify/ templates |
| **Continuous Claude** | continuous-claude.sh, spec-generate.sh |
| **Project context** | hackathon26 CLAUDE.md, TODO.md, DEMO-RUNBOOK.md, all rules |
| **Git credentials** | GitHub tokens for grobomo (altarr/boothapp) and tmemu (bridge repo) |
| **AWS credentials** | Hackathon profile creds for S3/Lambda/Bedrock access |
| **Chrome + deps** | Pre-installed in Docker image (for Blueprint browser automation) |

### Bundle delivery
1. `bundle.js` builds the archive on Joel's laptop (or on dispatcher)
2. Archive is SCP'd to each worker on first boot
3. `install.js` unpacks to `~/.claude/`, `/opt/claude-portable/`, and `/workspace/`
4. Workers never need to download tools from internet (though outbound is available as fallback)

## Development Phases

### Phase 1: Single Dev Worker (the seed)

Build ONE worker container on ONE EC2 instance. Manually iterate on it until it can:
- Accept a task description
- Clone a repo
- Read specs/context
- Implement code with GSD tracking
- Run tests
- Create a PR
- Report completion

This worker is the **seed** — every subsequent worker is a clone of this one.

**Polling/interrupt mechanism**: The worker writes a heartbeat file every 60s to a known path (`/workspace/.heartbeat.json`) containing:
```json
{"pid": 1234, "task": "building X", "status": "running|idle|error", "last_activity": "2026-03-29T19:00:00Z", "commits": 3, "tests_passed": true}
```
Joel (or dispatcher) can SSH in and `cat /workspace/.heartbeat.json` to check status without disrupting the running claude process.

**Success criteria**: Worker completes 3 consecutive tasks with zero manual intervention.

### Phase 2: Ephemerality Testing

Tear down the dev worker. Rebuild from scratch using only:
- CloudFormation template
- Docker image (built from Dockerfile)
- Environment bundle (SCP'd post-boot)

**Success criteria**: New worker completes a task within 5 minutes of instance launch. No manual SSH intervention.

### Phase 3: Dispatcher

Build the dispatcher on its own EC2 instance. The dispatcher:
- Polls the git-relay bridge repo every 30s
- Picks up pending tasks
- Optionally generates specs (if Claude CLI is authenticated)
- Assigns tasks to idle workers via SSH
- Tracks completion/failure
- Pushes results back to bridge repo
- Recovers orphaned dispatched tasks

The dispatcher also runs:
- Health API on :8080
- Dashboard server on :8082
- Nginx proxy config generation

**The dispatcher is built BY the dev worker.** Submit the dispatcher spec as a task, worker implements it.

### Phase 4: Dispatcher + Worker Integration

- Dispatcher launches with 2 workers
- Submit 5 tasks via bridge
- All 5 complete with PRs
- Test worker failure recovery (kill a worker mid-task, verify dispatcher reassigns)
- Test scaling: add worker-3 via CF, register with dispatcher, verify it picks up tasks

### Phase 5: RONE Teams Chat Integration

The RONE Teams poller (running on internal K8s) already uses a git-relay pattern:
- Poller detects `@claude` messages in Teams chat
- Writes task to bridge repo `requests/pending/`
- Dispatcher picks it up, dispatches to worker
- Worker completes, result written to `requests/completed/`
- Poller reads result, posts to Teams chat

**Same git inbox/outbox pattern.** The bridge repo is the universal message bus:
```
requests/
  pending/     ← new tasks (from RONE poller, Joel's laptop, or any source)
  dispatched/  ← claimed by dispatcher
  completed/   ← worker finished successfully
  failed/      ← worker failed
```

All communication flows through git. No direct network connections between RONE and AWS.

### Phase 6: Monitoring Dashboard

Built BY the workers (submitted as a task through the bridge).

Dashboard features:
- **Fleet status**: Worker count, idle/busy/error states, uptime
- **Task pipeline**: Pending → dispatched → completed/failed counts, avg completion time
- **Nginx audit**: Request count, error rate, top endpoints, suspicious patterns
- **Git relay**: Commit rate, queue depth, staleness
- **Worker detail**: Current task, last heartbeat, commits this session, test results
- **Auto-refresh**: Every 60s

Data sources:
- Dispatcher `/health` API
- Worker heartbeat files (via dispatcher SSH)
- Nginx audit logs (from S3 or local file)
- Git relay repo state

Served by nginx at `/dash`.

### Phase 7: E2E Testing Framework

The dispatcher generates E2E tests for every multi-task spec:
1. After spec generation, dispatcher creates `tests/e2e-{task-id}.sh`
2. Test script validates: all PRs created, all tests pass, no regressions
3. After worker completes, dispatcher runs E2E test on a clean clone
4. Test results written to bridge repo `results/e2e/`

For single tasks, the worker itself runs tests before creating the PR (already enforced by GSD gate).

### Phase 8: Self-Improvement Loop

Once the full system is operational:
1. Submit "improve CCC worker Dockerfile" as a task
2. Worker analyzes its own Dockerfile, proposes optimizations
3. PR merged → new Docker image built on dispatcher
4. Rolling update: workers pull new image on next task
5. System iteratively improves itself

## Success Criteria

- [ ] All AWS resources tagged `Project: hackathon26`, cleanly teardown-able
- [ ] Single CF command creates a complete worker (boot → ready in <5 min)
- [ ] Workers operate with zero manual SSH intervention
- [ ] Dispatcher polls bridge, assigns work, tracks results autonomously
- [ ] RONE Teams chat messages flow through bridge to workers and back
- [ ] Dashboard shows real-time fleet health at nginx `/dash`
- [ ] Nginx is the ONLY externally exposed port (443)
- [ ] Nginx audit logs capture all requests in JSON, ship to S3
- [ ] Environment bundle contains ALL required tools/configs (airgapped-ready)
- [ ] E2E tests run automatically after each multi-task completion
- [ ] System can rebuild any component from scratch with zero manual steps
- [ ] BoothApp demo is completed BY this system (not by Joel manually)

## Disaster Recovery

### Nginx HA
- **Primary + standby** nginx instances. Standby is a stopped EC2 instance (same CF template, same config).
- Primary writes heartbeat to S3 every 30s (`hackathon26-state-{id}/nginx-heartbeat.json`).
- Standby runs a cron job that polls S3 heartbeat. If stale >2 minutes, standby:
  1. Starts itself (already running as a monitor, just activates nginx)
  2. Reassociates the Elastic IP from primary to itself
  3. Logs the failover event to S3
- Failover is automatic, <2 minute recovery.

### Component Failure Handling
| Component | Detection | Recovery | RTO |
|-----------|-----------|----------|-----|
| Worker | Heartbeat stale >5 min | Dispatcher marks failed, resubmits task, CF recreates instance | ~5 min |
| Dispatcher | S3 leader heartbeat stale | Standby promotes (existing S3 election), workers queue | ~2 min |
| Nginx primary | S3 heartbeat stale >2 min | Standby auto-activates, EIP reassociation | ~2 min |
| Bridge repo | Git corruption | Force-push from reflog or re-clone from GitHub | ~1 min |

### DR Testing
After full system is operational, test each failure scenario. Document recovery times. This is the LAST phase before demo day.

## Documentation Requirements

All code produced by this system MUST be self-documenting:
- **Inline comments**: Every non-obvious design decision gets a comment explaining WHY, not WHAT
- **CF templates**: Description field on every resource explaining its purpose and relationships
- **Scripts**: Header comment block with usage, dependencies, and examples
- **Config files**: Comments explaining each setting and what happens if you change it
- **Architecture docs**: Generated alongside code, not as an afterthought
- **Decision log**: Each phase produces a `decisions.md` documenting what was chosen and what was rejected

Workers are instructed (via CLAUDE.md context) to document as they code. The GSD gate enforces that PRs include updated docs when architecture changes.

## Out of Scope

- Multi-region deployment (single AZ is acceptable)
- Auto-scaling based on queue depth (manual worker count for now)
- Cost optimization beyond spot instances
- Authentication for dashboard (internal-only via VPN or IP whitelist)
- Windows worker support (Linux Docker only)
- AWS service-level failures (S3, EC2 API) — rely on AWS SLA
