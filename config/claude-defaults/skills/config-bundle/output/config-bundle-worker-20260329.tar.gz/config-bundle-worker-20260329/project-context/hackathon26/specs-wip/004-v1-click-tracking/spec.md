# Feature Specification: V1 Click Tracking via CCC Worker + Blueprint

**Feature Branch**: `004-v1-click-tracking`
**Created**: 2026-03-29
**Status**: Draft
**Input**: Develop and test the Chrome extension's click tracking against real Vision One UI using a CCC worker with Blueprint MCP.

## Problem

The Chrome extension (`boothapp/extension/`) captures clicks, DOM paths, and screenshots — but it's never been tested against Vision One's actual UI. V1 uses complex Angular components, shadow DOM, dynamic routing, and nested iframes. The extension needs V1-specific enhancements to capture meaningful data during booth demos.

## Approach

1. Spin up a new CCC worker from the latest golden image (CF template + config-bundle)
2. Worker runs continuous-claude against boothapp repo
3. Worker uses Blueprint MCP (Chrome + Xvfb already in Docker image) to:
   - Load the Chrome extension in a real Chrome instance
   - Navigate Vision One (endpoint security, XDR, risk insights, etc.)
   - Verify clicks are captured with correct DOM paths
   - Identify V1-specific DOM patterns that need special handling
   - Fix/enhance the extension for V1's UI
4. Each task = commit + PR against altarr/boothapp

## User Scenarios & Testing

### US1 - Pull Golden Image & Deploy Worker (P1)

Deploy a fresh CCC worker using the latest claude-portable image and config-bundle. Worker must be ready to accept continuous-claude tasks.

**Acceptance**: `bash scripts/fleet/check-heartbeat.sh hackathon26-worker-v1` returns idle.

### US2 - Extension Loads in Worker's Chrome (P1)

Worker uses Blueprint to launch Chrome with the extension loaded, navigates to a test page, clicks elements, and verifies clicks.json is populated.

**Acceptance**: e2e test script confirms clicks.json has correct entries after 5 clicks on a test page.

### US3 - V1 Click Tracking Works (P1)

Worker navigates real V1 console pages (Endpoint Security, XDR Search, Risk Insights), clicks through the UI, and verifies the extension captures meaningful DOM paths (not just generic `div > div > div`).

**Acceptance**: clicks.json entries for V1 pages have descriptive DOM paths with V1-specific selectors (class names, data attributes, component tags).

### US4 - V1-Specific Enhancements (P2)

Based on US3 findings, enhance the extension to handle V1 patterns: Angular component boundaries, shadow DOM piercing, dynamic route detection, iframe content.

**Acceptance**: Re-run US3 e2e test with enhanced extension — DOM paths are descriptive and screenshots capture V1 UI state.

## Requirements

- **FR-001**: Script to deploy worker from golden image: `scripts/fleet/deploy-v1-worker.sh`
- **FR-002**: Script to pull latest golden image (config-bundle) to existing worker: `scripts/fleet/pull-golden-image.sh`
- **FR-003**: Worker tasks dispatched via continuous-claude with `TASK_FILE=specs/004-v1-click-tracking/tasks.md`
- **FR-004**: E2e test script: `scripts/test/test-v1-click-tracking.sh` — loads extension, clicks V1 pages, validates clicks.json
- **FR-005**: All V1 navigation uses Blueprint MCP (no manual browser interaction)
- **FR-006**: Extension enhancements are PRs against altarr/boothapp

## Success Criteria

- **SC-001**: Worker deploys from golden image in <15 min
- **SC-002**: Extension captures 5+ clicks on V1 with descriptive DOM paths
- **SC-003**: Screenshots show actual V1 UI state (not blank/loading)
- **SC-004**: Zero manual SSH intervention during development
- **SC-005**: All changes delivered as PRs via continuous-claude
