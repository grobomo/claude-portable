# Feature Specification: Seed Worker Bundle

**Feature Branch**: `003-seed-worker-bundle`
**Created**: 2026-03-29
**Status**: Draft
**Input**: Phase 7.1 — S3-sourced Docker build, config-bundle golden image, self-validating CCC worker.

## User Scenarios & Testing

### User Story 1 - Deploy Worker From Scratch (Priority: P1)

An operator runs a single deploy script. CloudFormation creates an EC2 spot instance that pulls a pre-built source zip from S3 (not git clone), builds the Docker image, starts the container, and reports healthy via heartbeat — all without SSH intervention.

**Why this priority**: Without a working worker, nothing else matters. This is the foundation.

**Independent Test**: Run `scripts/aws/deploy-stack.sh hackathon26-worker-dev ...` and verify the heartbeat file appears in `/workspace/.heartbeat.json` within 15 minutes.

**Acceptance Scenarios**:

1. **Given** no worker exists, **When** operator runs the deploy script, **Then** a running worker with Docker container appears within 15 minutes
2. **Given** a deployed worker, **When** the heartbeat is read, **Then** it reports status=idle, container=running
3. **Given** the S3 source zip, **When** the worker builds, **Then** it never clones from GitHub (air-gap ready)

---

### User Story 2 - Golden Image Bundle Install (Priority: P1)

After the worker boots, operator runs a bundle-deploy script that builds the config-bundle locally, SCPs it to the worker, and runs the installer. The worker then has all hooks, rules, GSD gates, speckit commands, skills, and binaries needed to accept tasks autonomously.

**Why this priority**: A worker without its environment config is useless — it can't follow the spec-driven workflow.

**Independent Test**: Run `scripts/fleet/deploy-bundle.sh hackathon26-worker-dev`, then verify all 8 config-bundle components are present inside the container.

**Acceptance Scenarios**:

1. **Given** a booted worker, **When** bundle-deploy script runs, **Then** all hooks, rules, skills, and binaries are installed in the container
2. **Given** an installed bundle, **When** `claude --version` runs in the container, **Then** it returns a valid version
3. **Given** an installed bundle, **When** listing hooks in the container, **Then** spec-gate, gsd-gate, enforcement-gate, no-adhoc-commands, archive-not-delete, aws-tagging-gate all exist

---

### User Story 3 - Self-Validation (Priority: P2)

After bundle install, operator runs a validation script that submits 3 test tasks through the bridge. Each task must complete (PR created or result file written) with zero SSH intervention. If any fail, the script reports which task failed and why.

**Why this priority**: Proves the worker is production-ready. Without validation, we ship untested infrastructure.

**Independent Test**: Run `scripts/test/validate-worker.sh hackathon26-worker-dev` and observe 3/3 tasks complete.

**Acceptance Scenarios**:

1. **Given** a bundled worker, **When** 3 test tasks are submitted via bridge, **Then** all 3 complete within 10 minutes each
2. **Given** a task failure, **When** validation script detects it, **Then** it prints the failure reason and exits non-zero
3. **Given** all tasks pass, **When** validation completes, **Then** it prints "VALIDATED: 3/3 tasks passed" and exits 0

---

### Edge Cases

- Worker spot instance gets reclaimed during Docker build — CF stack shows failed, deploy script can be re-run
- S3 source zip is missing or corrupt — userdata fails early, init log shows the error
- Bundle SCP fails (SSH not yet ready) — deploy-bundle script retries with backoff
- Worker disk fills during Docker build — heartbeat reports disk_free, 50GB root volume should suffice
- Claude CLI not authenticated on worker — bundle install must handle auth setup

## Requirements

### Functional Requirements

- **FR-001**: Worker CF template MUST pull Docker source from S3 zip, not git clone
- **FR-002**: `scripts/aws/deploy-stack.sh` MUST handle create, update, and rollback-recovery for worker stacks
- **FR-003**: `scripts/aws/upload-source.sh` MUST package claude-portable repo as zip and upload to S3 state bucket
- **FR-004**: `scripts/fleet/deploy-bundle.sh` MUST build config-bundle, SCP to worker, run installer inside container
- **FR-005**: `scripts/fleet/deploy-bundle.sh` MUST handle Claude CLI auth setup on the worker
- **FR-006**: `scripts/test/validate-worker.sh` MUST submit 3 tasks via bridge.py and verify completion
- **FR-007**: All scripts MUST be self-contained — no ad-hoc commands needed between them
- **FR-008**: Worker heartbeat MUST report status (idle/running/error), container state, disk free, uptime
- **FR-009**: All AWS resources MUST be tagged with `Project=hackathon26`
- **FR-010**: All scripts MUST source `scripts/aws/common.sh` for shared constants

### Key Entities

- **Worker Stack**: CF stack containing EC2 instance + EIP, identified by stack name
- **Source Zip**: claude-portable repo archived as `.tar.gz` in S3 state bucket
- **Config Bundle**: tar.gz containing hooks, rules, skills, binaries, CLAUDE.md — built by config-bundle skill
- **Heartbeat**: JSON file at `/workspace/.heartbeat.json` updated every 60s by host-side script
- **Bridge Task**: JSON file in RONE-boothapp-bridge `requests/pending/` consumed by dispatcher

## Success Criteria

### Measurable Outcomes

- **SC-001**: Worker deploys from zero to idle heartbeat in under 15 minutes
- **SC-002**: Bundle deploy completes in under 3 minutes
- **SC-003**: All 3 validation tasks complete with zero SSH intervention
- **SC-004**: Full cycle (deploy + bundle + validate) completes in under 30 minutes
- **SC-005**: Worker can be torn down and rebuilt from scratch by re-running the same scripts
- **SC-006**: Zero ad-hoc commands needed — every operation is a script call

## Assumptions

- S3 state bucket (`hackathon26-state-752266476357`) already exists (deployed by hackathon26-storage stack)
- SSH key `claude-portable-key.pem` exists locally at `~/.ssh/ccc-keys/`
- Bridge repo (`RONE-boothapp-bridge`) is accessible for task submission
- Claude CLI auth can be injected via API key environment variable (no interactive login)
- config-bundle skill exists and produces a valid tar.gz
