# Research: Seed Worker Bundle

## R1: S3 Source Zip vs Git Clone

**Decision**: Upload claude-portable as tar.gz to S3 state bucket. Worker userdata downloads and extracts.
**Rationale**: Git clone requires GitHub access at boot time. S3 is in-VPC, faster, air-gap ready. The state bucket already exists.
**Alternatives considered**:
- Git clone (current): requires GitHub access, slower, breaks in air-gap scenarios
- Pre-baked AMI: faster boot but AMI management overhead, stale images
- ECR Docker image: ideal for production but requires ECR setup (overkill for hackathon)

## R2: Config Bundle Delivery

**Decision**: Build config-bundle on local machine, SCP tar.gz to worker host, docker cp into container, run install.js.
**Rationale**: config-bundle skill already builds the archive. SCP is simple and reliable. No additional infrastructure needed.
**Alternatives considered**:
- S3 upload + download: extra step, bundle changes frequently during dev
- Bake into Docker image: requires image rebuild for config changes
- Git clone config repo: circular dependency (worker needs config to use git properly)

## R3: Claude CLI Auth on Workers

**Decision**: Inject API key as environment variable (`ANTHROPIC_API_KEY`) via docker exec, persisted in container's `.bashrc`.
**Rationale**: Workers need Claude CLI for task execution. API key injection is simpler than interactive `claude /login`. Key is already in OS credential store locally.
**Alternatives considered**:
- Interactive login: requires TTY, can't automate
- OAuth token: expires, needs refresh mechanism
- Mount credentials file: ties to host filesystem layout

## R4: Validation Approach

**Decision**: Submit 3 small self-contained tasks via bridge.py, poll for completion, check exit status.
**Rationale**: Tests the full pipeline (bridge -> dispatcher -> worker -> PR/result) without needing a dispatcher yet. For seed worker, tasks can be self-contained (no PR, just write a result file).
**Alternatives considered**:
- SSH health check: doesn't test Claude execution path
- Docker exec test: doesn't test bridge/dispatch path
- Manual verification: violates zero-intervention requirement

## R5: Heartbeat Mechanism

**Decision**: Host-side bash script writes JSON to shared volume every 60s. Docker container status checked via `docker inspect`.
**Rationale**: If container crashes, host script still reports error state. Shared volume makes heartbeat readable from both host and container.
**Alternatives considered**:
- In-container heartbeat: dies when container dies
- CloudWatch agent: AWS dependency, complex setup
- S3 heartbeat upload: network dependency, cost
