# Tasks: Self-Building CCC System

## Phase 0: Teardown Legacy Resources
- [ ] Tag all existing CF stacks for identification: `ccc-dispatcher`, `ccc-worker-1`, `ccc-worker-2`
- [ ] Stop all running containers on existing instances (dispatcher 18.224.39.180, workers 3.21.228.154, 13.59.160.30)
- [ ] Delete CF stacks: `ccc-dispatcher`, `ccc-worker-1`, `ccc-worker-2`
- [ ] Verify all EC2 instances terminated, EBS volumes released
- [ ] Keep S3 bucket `boothapp-sessions-752266476357` (has demo data) but tag it `Project: hackathon26`
- [ ] Keep SSH keypair `claude-portable-key` in AWS (reuse)
- [ ] Update local fleet-config.sh to clear old IPs

## Phase 1: Seed Worker
### 1.1 CloudFormation Templates
- [ ] Create `hackathon26-network.yaml`: security groups (SG-nginx: 443 inbound, SG-internal: all from SG-nginx + SSH from Joel IP, SG-worker: inbound only from SG-internal)
- [ ] Create `hackathon26-storage.yaml`: S3 bucket `hackathon26-state-{AccountId}` (audit logs, heartbeats, state), IAM instance profile with S3 + Bedrock + ECR access
- [ ] Create `hackathon26-worker.yaml`: EC2 spot (t3.large), Docker CE userdata, pulls image from dispatcher or builds locally, applies bundle via SCP, tags `Project: hackathon26, Component: ccc-worker`
- [ ] Deploy network + storage stacks
- [ ] Deploy one worker stack (`hackathon26-worker-dev`)

### 1.2 Docker Image
- [ ] Update Dockerfile: pin Claude CLI version, install all MCP servers (mcp-manager, blueprint-extra, v1-api) at build time, install uv + spec-kit deps
- [ ] Add heartbeat.sh to image (background process, writes /workspace/.heartbeat.json every 60s)
- [ ] Add entrypoint.sh: starts heartbeat, applies bundle if present at /opt/bundle/, starts SSH daemon, drops to claude user
- [ ] Build image on dev worker instance, test `docker run` → verify Claude CLI works, Chrome works, MCP servers start

### 1.3 Environment Bundle v2
- [ ] Extend config-bundle to include ALL binaries: mcp-manager binary, blueprint-extra-mcp binary, v1-api binary
- [ ] Add git credential injection to install.js (write .git-credentials + .gitconfig for grobomo + tmemu)
- [ ] Add AWS credential injection (write ~/.aws/credentials with hackathon profile)
- [ ] Add Claude OAuth token injection (write to ~/.claude/ auth location)
- [ ] Version the bundle (manifest.json with semver + build timestamp)
- [ ] Test: SCP bundle to dev worker, run install.js, verify all tools work

### 1.4 Worker Validation
- [ ] Submit test task to dev worker manually (SSH in, run `claude -p "clone altarr/boothapp, add a comment to README, PR"`)
- [ ] Verify: PR created, tests pass, GSD artifacts generated
- [ ] Submit 3 consecutive tasks — all must complete without SSH intervention
- [ ] Verify heartbeat.json updates every 60s with correct status
- [ ] Verify worker can access: GitHub (grobomo + tmemu repos), S3 (boothapp-sessions), Bedrock (claude-sonnet)

## Phase 2: Ephemerality
- [ ] Terminate dev worker EC2 instance
- [ ] Re-deploy `hackathon26-worker-dev` stack from CF
- [ ] Wait for instance boot (userdata installs Docker, pulls/builds image)
- [ ] SCP bundle from laptop, run install.js
- [ ] Submit task — must complete successfully within 5 minutes of bundle install
- [ ] Document total time: CF create → task complete
- [ ] Automate: create `scripts/launch-worker.sh` that does CF create-stack + wait + SCP bundle + install in one command

## Phase 3: Dispatcher
- [ ] Create `hackathon26-dispatcher.yaml`: EC2 spot (t3.small), same Docker image, SG-internal, tags `Project: hackathon26, Component: ccc-dispatcher`
- [ ] Deploy dispatcher stack
- [ ] SCP bundle + git-dispatch.py to dispatcher
- [ ] Configure dispatcher: relay repo URL, poll interval, worker registry
- [ ] **Submit "build the dispatcher health API" as a task to the dev worker** — worker implements it, creating a self-referential loop
- [ ] Start dispatcher daemon, register dev worker
- [ ] Test: submit task via bridge.py → dispatcher picks up → assigns to worker → worker completes → result in bridge

## Phase 4: Integration
- [ ] Deploy `hackathon26-worker-1` and `hackathon26-worker-2` stacks
- [ ] SCP bundle to both workers, run install.js
- [ ] Register both workers with dispatcher
- [ ] Submit 5 tasks simultaneously via bridge
- [ ] Verify: all 5 complete, distributed across workers, no conflicts
- [ ] Kill worker-1 mid-task (terminate instance) — verify dispatcher detects failure, resubmits to worker-2
- [ ] Re-deploy worker-1 via CF, re-register — verify it picks up new tasks
- [ ] Test config-bundle push: update bundle on laptop, run deploy-worker-bundle.sh → all workers updated

## Phase 5: RONE Teams Integration
- [ ] Verify RONE poller still running in K8s (kubectl get pods)
- [ ] Verify RONE poller writes to same bridge repo (`joel-ginsberg_tmemu/RONE-boothapp-bridge`)
- [ ] Test: send `@claude add a health check to analysis/watcher.js` in Teams chat
- [ ] Verify: poller detects → writes to bridge → dispatcher picks up → worker completes → result in bridge → poller posts result to Teams
- [ ] Test full round-trip latency (message → Teams reply)

## Phase 6: Monitoring Dashboard
- [ ] **Submit "build monitoring dashboard" as a task to CCC fleet** — workers build it themselves
- [ ] Dashboard spec: fleet status, task pipeline, nginx audit, git relay, worker detail panels
- [ ] Dashboard polls: dispatcher /health, worker heartbeats (via dispatcher SSH), nginx audit log, bridge repo
- [ ] Auto-refresh every 60s
- [ ] Served by dispatcher on :8082, proxied by nginx at /dash
- [ ] Verify: dashboard shows all components green, task counts accurate

## Phase 7: E2E Testing Framework
- [ ] **Submit "build E2E test framework" as a task to CCC fleet**
- [ ] Dispatcher generates E2E tests from spec success criteria after multi-task specs
- [ ] After worker completes, dispatcher runs E2E test on clean clone
- [ ] E2E results written to bridge `results/e2e/{task-id}.json`
- [ ] Dashboard shows E2E pass/fail status per task
- [ ] Test: submit multi-task spec, verify E2E test generated + runs + passes

## Phase 8: Nginx Proxy
- [ ] Create `hackathon26-nginx.yaml`: EC2 spot (t3.micro), nginx + certbot, SG-nginx (only 443 inbound), self-signed cert
- [ ] Deploy nginx stack
- [ ] Configure routes: /health → dispatcher, /dash → dashboard, /relay/ → dispatcher, /audit → log viewer
- [ ] Enable JSON audit logging (all requests logged with time, remote, method, uri, status, latency, user_agent)
- [ ] Log rotation: daily, ship to S3 `hackathon26-state-{AccountId}/audit-logs/`
- [ ] Remove direct port exposure from dispatcher + worker security groups — only nginx SG allows inbound
- [ ] Verify: `curl -sk https://<nginx-ip>/dash` returns dashboard, `curl -sk https://<nginx-ip>/health` returns JSON
- [ ] Verify: direct access to dispatcher:8080 from internet is BLOCKED

## Phase 9: BoothApp Development (via CCC)
- [ ] Submit remaining boothapp tasks as specs through bridge:
  - Chrome extension V1 demo environment test
  - Audio capture + transcription flow
  - Full E2E demo: badge scan → session → recording → analysis → report
- [ ] All development done BY workers, not by Joel
- [ ] All PRs reviewed via dashboard
- [ ] Final demo rehearsal using CCC-built components

## Phase 10: Documentation
- [ ] **Submit "generate system documentation" as a task to CCC fleet**
- [ ] Architecture diagram (Mermaid or D2) showing all components + data flow
- [ ] Runbook: how to deploy from scratch, how to tear down, how to debug
- [ ] Bundle contents inventory with versions
- [ ] Bridge protocol specification
- [ ] Dashboard user guide
- [ ] Update hackathon26 CLAUDE.md with final architecture

## Phase 11: Disaster Recovery
- [ ] Create `hackathon26-nginx-standby.yaml`: identical to nginx stack but in standby (instance stopped)
- [ ] Build standby health monitor: primary nginx heartbeat to S3 every 30s, standby polls S3, auto-starts if primary stale >2 min
- [ ] DR plan document covering:
  - Worker failure: dispatcher detects via heartbeat, resubmits task, CF rebuilds instance
  - Dispatcher failure: standby promotion (S3 leader election already exists), workers queue tasks
  - Nginx failure: standby auto-activates, DNS/IP swap (Elastic IP reassociation)
  - Bridge repo corruption: force-push from last known good state (git reflog)
  - S3 bucket failure: out of scope (AWS managed, cross-AZ by default)
- [ ] Test DR scenarios:
  - [ ] Kill primary nginx — verify standby activates within 2 minutes
  - [ ] Kill dispatcher — verify standby promotes, workers resume
  - [ ] Kill worker mid-task — verify task resubmitted and completed by another worker
  - [ ] Terminate ALL workers — verify dispatcher queues tasks, new workers pick up after deploy
- [ ] Document DR test results with timestamps and recovery times
