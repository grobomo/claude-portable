# Implementation Plan: Self-Building CCC System

## Pre-requisites

- AWS account 752266476357, region us-east-2, profile `hackathon`
- SSH key `claude-portable-key` in AWS + local `~/.ssh/ccc-keys/`
- GitHub tokens: grobomo (boothapp), tmemu (bridge, hackathon26)
- Claude OAuth token (for workers to run `claude -p`)
- Anthropic API key OR AWS Bedrock access (for analysis pipeline)

## Technical Approach

### CloudFormation Stack Design

Every component gets its own CF stack with `hackathon26-` prefix:

| Stack | Resources | Depends On |
|-------|-----------|------------|
| `hackathon26-network` | VPC (or use default), SG-nginx (443 from 0.0.0.0), SG-internal (all from SG-nginx + SSH from Joel IP), SG-worker (no inbound except SG-internal) | — |
| `hackathon26-storage` | S3 bucket (sessions + audit logs + state), IAM role for EC2 instances | network |
| `hackathon26-nginx` | EC2 spot (t3.micro), nginx config, certbot, audit log rotation | network, storage |
| `hackathon26-dispatcher` | EC2 spot (t3.small), Docker, git-dispatch.py, dashboard | network, storage |
| `hackathon26-worker-N` | EC2 spot (t3.large), Docker, claude-portable image, bundle | network, storage |

### Docker Image Strategy

Single Dockerfile produces ONE image used by both dispatcher and workers:
- Base: node:20-bookworm + Chrome + Python + AWS CLI + uv
- Claude CLI installed at build time (pinned version)
- MCP servers installed at build time
- Config bundle applied at container start (not bake time) — enables hot-patching

Image built on dispatcher, pushed to ECR (or just `docker save/load` via SCP for airgapped).

### Git Relay Protocol

```
bridge-repo/
  requests/
    pending/{timestamp}-{hex}.json     ← submitter writes
    dispatched/{timestamp}-{hex}.json  ← dispatcher moves here
    completed/{timestamp}-{hex}.json   ← dispatcher moves after worker success
    failed/{timestamp}-{hex}.json      ← dispatcher moves after worker failure
  results/
    e2e/{task-id}.json                 ← dispatcher writes E2E test results
```

Message format:
```json
{
  "sender": "rone-poller|joel-local|dispatcher",
  "text": "task description",
  "context": ["last 25 messages for chat context"],
  "timestamp": "ISO8601",
  "chat_id": "source identifier",
  "priority": "normal|high",
  "spec": null | {"tasks": ["task1", "task2"], "repo": "altarr/boothapp"}
}
```

### Worker Heartbeat + Polling

Workers write `/workspace/.heartbeat.json` every 60s via a background process:
```bash
# heartbeat.sh — runs as background process in container
while true; do
  CLAUDE_PID=$(pgrep -f 'claude -p ' | head -1)
  if [ -n "$CLAUDE_PID" ]; then
    STATUS="running"
    TASK=$(cat /proc/$CLAUDE_PID/cmdline | tr '\0' ' ' | head -c 200)
  else
    STATUS="idle"
    TASK=""
  fi
  cat > /workspace/.heartbeat.json <<EOF
  {"pid":${CLAUDE_PID:-0},"status":"$STATUS","task":"$TASK",
   "last_activity":"$(date -u +%Y-%m-%dT%H:%M:%SZ)",
   "disk_free":"$(df -h /workspace | tail -1 | awk '{print $4}')",
   "uptime":"$(cat /proc/uptime | awk '{print $1}')"}
EOF
  sleep 60
done
```

Dispatcher reads this via SSH to check worker health without interrupting.

### Nginx Configuration

```nginx
# /etc/nginx/sites-enabled/hackathon26.conf
log_format audit escape=json
  '{"time":"$time_iso8601","remote":"$remote_addr",'
  '"method":"$request_method","uri":"$uri",'
  '"status":$status,"bytes":$body_bytes_sent,'
  '"upstream":"$upstream_addr","latency":$request_time,'
  '"user_agent":"$http_user_agent"}';

server {
    listen 443 ssl;
    ssl_certificate /etc/letsencrypt/live/hackathon26/fullchain.pem;
    ssl_certificate_key /etc/letsencrypt/live/hackathon26/privkey.pem;

    access_log /var/log/nginx/audit.log audit;

    location /health { proxy_pass http://dispatcher:8080/health; }
    location /dash   { proxy_pass http://dispatcher:8082/; }
    location /relay/ { proxy_pass http://dispatcher:8080/relay/; }
    location /audit  {
        alias /var/log/nginx/;
        autoindex on;
        types { application/json log; }
    }
}
```

Self-signed cert initially (no domain). Joel accesses via `https://<nginx-ip>/dash`.

### E2E Test Generation

Dispatcher creates E2E tests after multi-task specs:

```python
def generate_e2e_test(spec_dir, task_id, repo_url):
    """Generate an E2E test script from spec success criteria."""
    spec = read_file(f"{spec_dir}/spec.md")
    criteria = extract_success_criteria(spec)

    test_script = f"""#!/bin/bash
    set -euo pipefail
    REPO={repo_url}
    git clone $REPO /tmp/e2e-{task_id}
    cd /tmp/e2e-{task_id}

    # Verify all PRs merged
    {generate_pr_checks(criteria)}

    # Run test suite
    npm test 2>&1 || exit 1

    # Check success criteria
    {generate_criteria_checks(criteria)}

    echo "E2E PASS"
    """
    return test_script
```

## Dependency Order

```
Phase 0: Teardown legacy ──────────────────────────┐
Phase 1: CF templates (network + storage) ─────────┤
Phase 1: Docker image (Dockerfile + bundle) ───────┤
Phase 1: Dev worker launch + iterate ──────────────┤
Phase 2: Ephemerality test (teardown + rebuild) ───┤
Phase 3: Dispatcher (built by worker) ─────────────┤
Phase 4: Integration test (dispatcher + 2 workers) ┤
Phase 5: RONE bridge integration ──────────────────┤
Phase 6: Dashboard (built by workers) ─────────────┤
Phase 7: E2E framework (built by workers) ─────────┤
Phase 8: Self-improvement loop ────────────────────┘
```

Phase 1 is the critical path. Everything else flows from having a working worker.

## Risk Mitigation

| Risk | Mitigation |
|------|------------|
| Spot reclaim during task | Heartbeat goes stale → dispatcher marks failed → resubmits to another worker |
| Claude OAuth expires | Bundle includes refresh logic; Bedrock as fallback (no OAuth needed) |
| GitHub rate limits | Workers clone once, pull incrementally; dispatcher caches relay repo |
| Docker image too large | Multi-stage build; Chrome is biggest dep (~400MB), required for Blueprint |
| Bundle gets stale | Version in manifest.json; dispatcher checks version before dispatching |
| Worker can't access private repos | Git credential helper configured in bundle; tokens injected at boot |
