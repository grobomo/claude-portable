# Quickstart: Seed Worker Bundle

## Prerequisites
- AWS CLI configured with `hackathon` profile
- SSH key at `~/.ssh/ccc-keys/claude-portable-key.pem`
- `claude-portable` repo cloned at `~/Documents/ProjectsCL1/claude-portable/`
- Bridge repo accessible for task submission
- Anthropic API key in OS credential store

## Step 1: Upload Source Zip
```bash
bash scripts/aws/upload-source.sh
```
Packages claude-portable as tar.gz, uploads to S3 state bucket.

## Step 2: Deploy Worker
```bash
bash scripts/aws/deploy-stack.sh hackathon26-worker-dev cloudformation/hackathon26-worker.yaml \
  WorkerName=hackathon26-worker-dev InstanceType=t3.large
```
Creates EC2 spot instance, builds Docker image from S3 source, starts container.

## Step 3: Wait for Boot (~15 min)
```bash
bash scripts/fleet/check-heartbeat.sh hackathon26-worker-dev
```
Polls heartbeat until worker reports idle.

## Step 4: Deploy Config Bundle
```bash
bash scripts/fleet/deploy-bundle.sh hackathon26-worker-dev
```
Builds config-bundle, SCPs to worker, installs hooks/rules/skills/binaries.

## Step 5: Validate
```bash
bash scripts/test/validate-worker.sh hackathon26-worker-dev
```
Submits 3 test tasks via bridge, verifies all complete. Prints VALIDATED or FAILED.

## Teardown
```bash
bash scripts/aws/delete-stack.sh hackathon26-worker-dev
```
