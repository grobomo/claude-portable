# Tasks: V1 Click Tracking

**Input**: spec.md, plan.md
**Feature Branch**: 004-v1-click-tracking

---

## Phase 1: Golden Image Scripts

**Purpose**: Create reusable scripts to deploy workers and pull latest golden image.

- [x] T001 Create `scripts/fleet/pull-golden-image.sh` — builds config-bundle locally (node ~/.claude/skills/config-bundle/bundle.js), SCPs tar.gz to worker, docker cp into container, runs install.js. Accepts worker name as arg. Sources fleet-config.sh + common.sh.
- [x] T002 Create `scripts/fleet/deploy-v1-worker.sh` — deploys hackathon26-worker-v1 CF stack via deploy-stack.sh, waits for heartbeat, runs pull-golden-image.sh. Single command: zero to working worker.
- [x] T003 Create `scripts/fleet/check-heartbeat.sh` — SSH to worker, read /workspace/.heartbeat.json, retry with backoff for boot period, exit 0 if idle/running.

**Checkpoint**: Run `bash scripts/fleet/deploy-v1-worker.sh` — worker deploys, heartbeat reports idle, golden image installed. E2e: `bash scripts/fleet/check-heartbeat.sh hackathon26-worker-v1` exits 0.

---

## Phase 2: Worker Validation

**Purpose**: Verify worker can run continuous-claude and use Blueprint.

- [ ] T004 Create `scripts/test/test-worker-blueprint.sh` — SSHs to worker, runs `docker exec claude-portable claude -p "use Blueprint to open chrome and navigate to https://example.com, take a screenshot"`, verifies screenshot file exists in /workspace/.
- [ ] T005 Deploy worker-v1 stack and run pull-golden-image.sh against it.
- [ ] T006 Run test-worker-blueprint.sh — verify Blueprint works inside worker container.

**Checkpoint**: Worker has Chrome + Blueprint working. E2e: `bash scripts/test/test-worker-blueprint.sh hackathon26-worker-v1` exits 0.

---

## Phase 3: Extension Loading

**Purpose**: Get the Chrome extension loaded in worker's Chrome via Blueprint.

- [ ] T007 Create worker task script: clone boothapp repo in worker, launch Chrome with `--load-extension=/workspace/boothapp/extension` via Blueprint, navigate to test page, click 5 elements.
- [ ] T008 Create `scripts/test/test-extension-loading.sh` — submits T007 task to worker via bridge, waits for completion, checks that clicks.json was captured.
- [ ] T009 Run test-extension-loading.sh — verify extension captures clicks in worker's Chrome.

**Checkpoint**: Extension loads and captures clicks in worker Chrome. E2e: `bash scripts/test/test-extension-loading.sh` exits 0 with 5 clicks in clicks.json.

---

## Phase 4: V1 Navigation & Click Capture

**Purpose**: Test extension against real Vision One UI.

- [ ] T010 Create worker continuous-claude task: navigate V1 console with Blueprint (Endpoint Security, XDR Search, Risk Insights, Detection Models), click through each page, export clicks.json after each navigation.
- [ ] T011 Create `scripts/test/test-v1-click-tracking.sh` — submits V1 navigation task, waits for completion, validates clicks.json entries have descriptive DOM paths (not just generic div chains).
- [ ] T012 Run test-v1-click-tracking.sh — capture V1 click data, analyze DOM path quality.

**Checkpoint**: Extension captures V1 clicks with useful DOM paths. E2e: `bash scripts/test/test-v1-click-tracking.sh` exits 0, DOM paths contain V1-specific selectors.

---

## Phase 5: V1-Specific Enhancements

**Purpose**: Fix extension for V1's Angular/shadow DOM patterns based on Phase 4 findings.

- [ ] T013 Analyze Phase 4 click data — identify patterns where DOM paths are too generic or miss V1 component boundaries.
- [ ] T014 Submit worker task: enhance `buildDomPath()` in content.js to handle Angular component tags (`app-*`, `v1-*`), data-testid attributes, aria-label fallbacks, shadow DOM piercing.
- [ ] T015 Submit worker task: enhance screenshot capture — ensure V1 pages are fully rendered before capture (wait for Angular zone stable, loading spinners gone).
- [ ] T016 Re-run test-v1-click-tracking.sh with enhanced extension — verify DOM path quality improvement.

**Checkpoint**: Enhanced extension produces descriptive V1 DOM paths. E2e: re-run `bash scripts/test/test-v1-click-tracking.sh` — DOM paths contain Angular component names and V1 selectors.

---

## Phase 6: Cleanup & Merge

- [ ] T017 Update TODO.md with results and session notes.
- [ ] T018 Commit all scripts to 004-v1-click-tracking branch, create PR to main.
- [ ] T019 Verify all worker PRs merged to altarr/boothapp main.

**Checkpoint**: All changes committed, PRs merged, TODO.md updated.

---

## Dependencies

- Phase 1: No deps (can start immediately)
- Phase 2: Depends on Phase 1 (worker must exist)
- Phase 3: Depends on Phase 2 (Blueprint must work)
- Phase 4: Depends on Phase 3 (extension must load) + V1 tenant access
- Phase 5: Depends on Phase 4 (need click data to analyze)
- Phase 6: Depends on Phase 5

## E2E Test Strategy

Every checkpoint has a `scripts/test/` script that exits 0/1. No manual verification. Tests simulate the real user workflow: deploy worker, load extension, click V1, check output.
