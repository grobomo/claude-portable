# AWS Resource Tagging

All AWS resources created with `--profile hackathon` MUST include `Project=hackathon26` tag.

- CloudFormation: add `Tags` property with `Key: Project, Value: hackathon26`
- CLI commands: add `--tags Key=Project,Value=hackathon26`
- S3 buckets: tag after creation with `aws s3api put-bucket-tagging`
- A PreToolUse hook enforces this — commands without the tag are blocked
