# Plan: V1 Click Tracking via CCC Worker + Blueprint

## Architecture

```
hackathon26 (this repo, branch 004-v1-click-tracking)
  └── continuous-claude orchestrates locally
       └── tasks.md drives the work
            ├── Phase 1: Deploy worker (CF + config-bundle)
            ├── Phase 2: Submit continuous-claude tasks to worker
            └── Worker (hackathon26-worker-v1, EC2 spot)
                 └── continuous-claude in boothapp repo
                      ├── Blueprint MCP -> Chrome + extension
                      ├── Navigates V1, captures clicks
                      ├── Enhances extension code
                      └── PRs against altarr/boothapp
```

## Two-Level Continuous Claude

### Level 1: Orchestrator (this laptop, hackathon26 repo)
- Runs on branch `004-v1-click-tracking`
- Tasks: deploy worker, push golden image, submit worker tasks, validate results
- Tracks progress in `specs/004-v1-click-tracking/tasks.md`

### Level 2: Worker (EC2, boothapp repo)
- Runs continuous-claude with tasks dispatched from orchestrator
- Uses Blueprint MCP to control Chrome with extension loaded
- Creates branches and PRs against altarr/boothapp
- Reports results back via bridge

## Golden Image Pull Strategy

The other tab (003-seed-worker-bundle) builds the worker infra. This feature consumes it:

1. `scripts/fleet/pull-golden-image.sh <worker-name>` — builds config-bundle locally, SCPs to worker, runs installer
2. Called before each work session to pick up latest hooks/rules/skills
3. Idempotent — safe to run repeatedly

## V1 Access

- V1 tenant provided by Chris (demo tenant, pre-configured)
- Worker Chrome connects via Blueprint MCP (Xvfb + Chrome in Docker)
- Extension loaded via `--load-extension=/workspace/boothapp/extension`

## Key Decisions

- **Why Blueprint, not Puppeteer?** Blueprint is already in the Docker image and handles Chrome lifecycle. No extra deps.
- **Why worker, not local?** Extension testing needs Linux Chrome + Xvfb. Workers have this. Local Windows Chrome can't headlessly load extensions reliably.
- **Why continuous-claude on worker?** Multiple tasks (test, fix, enhance, re-test) — continuous-claude handles the loop, PRs each step.
